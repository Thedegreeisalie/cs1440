#include "Analyst.h"
#include "Trans.h"


Analyst::Analyst(std::string name, std::string inits, int howLong, std::string hist):
    name(name),
    inits(inits),
    howLong(howLong)
    {
        //Trans(hist);
    }